## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setupm-------------------------------------------------------------------
pacman::p_load(tidymodels,tidyverse,Alfaifi)

## -----------------------------------------------------------------------------
# install.packages("devtools")
devtools::install_github("bayanalfaifi/Alfaifi")

## -----------------------------------------------------------------------------
Alfaifi::flavor_profile

## -----------------------------------------------------------------------------
Alfaifi::ingr_list[1:10]

## -----------------------------------------------------------------------------


ingredients_choice <- 
  Alfaifi::prepare_data(.selected_ingredients = c('milk','potato','tomato',"chilli"),
               .flavor_profile  = "spicy")
ingredients_choice



## -----------------------------------------------------------------------------


ingredients_choice %>% 
  Alfaifi::prep_time()

## -----------------------------------------------------------------------------


ingredients_choice %>% 
  Alfaifi::cook_time()

## -----------------------------------------------------------------------------


ingredients_choice <- 
  Alfaifi::prepare_data(.selected_ingredients = c('onions','beans','olive',"fish","sugar"),
               .flavor_profile  = "sweet")
ingredients_choice



## -----------------------------------------------------------------------------


ingredients_choice %>% 
  Alfaifi::prep_time()

## -----------------------------------------------------------------------------


ingredients_choice %>% 
  Alfaifi::cook_time()

## ---- eval=FALSE--------------------------------------------------------------
#  # not run
#  # Run the gadget rec_time
#  ingredients %>% rec_time

